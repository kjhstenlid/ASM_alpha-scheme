#Site specific Microkinetic Model - Version 7

#Gas Phase Energies (0 K, Ry, O2 no corrections)
#If adding corrections, update the gas_energies_dft, and the intercepts in site_specific_O 

gas_energies_dft = {"NO": -52.28824454, "O2": -64.39106759, "N2": -40.34333541}

#Site Specific Scaling (BE_Ads = slope*site' + intercept)
# site' = site stability for top site
# site' = (1/2)*site stability for bridge site
# site' = (1/3)*site stability for hollow site

site_specific_NO = { "Pt": {"7-7": [-0.10024, -2.47888],
			    "8-8": [-0.45891, -4.11721],
			    "7-9-9": [-0.26874 ,-2.81609],
			    "9-9-9": [-0.28746, -3.02380]}}

site_specific_N = { "Pt": {"7-7": [-0.06957, 0.43467],
                            "8-8": [-0.40502, -0.93009],
                            "7-9-9": [-0.37429, -0.96766],
                            "9-9-9": [-0.41101, -1.49007]}}

site_specific_O = { "Pt": {"7-7": [0.12530, -0.6177],
                            "8-8": [-0.30961, -2.4692],
			    "7-9-9": [0.2557, 0.6393],
                            "9-9-9": [-0.2045, -1.9134]}}

#Transition State Scaling (Falsig et al. (2014), Topics in Catalysis, E_TS = slope*E_Diss + intercept) 
#E_TS = ETS/slab - Eslab - Egas
#Ediss = EA/slab + EB/slab - 2*Eslab - Egas 

TSS_NO = {"7-7": [0.79, 1.09], "8-8": [0.73, 1.26], "7-9-9": [0.74, 1.74], "9-9-9": [0.74, 1.74]}
TSS_O2 = {"7-7": [0.55, 1.03], "8-8": [0.53, 0.93], "7-9-9": [0.71, 1.84], "9-9-9": [0.71, 1.84]}
TSS_N2 = {"7-7": [0.81, 1.76], "8-8": [0.80, 2.25], "7-9-9": [0.78, 2.32], "9-9-9": [0.78, 2.32]}

#Gas Phase Entropy (Shomate)
#NIST Webbook at 1 bar

Shomate = {"NO": [23.83491, 12.58878, -1.139011, -1.497459, 0.214194, 237.1219],
	   "N2": [19.50583, 19.88705, -8.598535, 1.369784, 0.527601, 212.3900],
	   "O2": [31.32234, -20.23531, 57.866440, -36.506240, -0.007374, 246.7945]} 

#Vibrational Frequencies of Surface Adsorbates (Harmonic approximation)

vib = {"O_ad": [336.4, 337.3, 406.1],
       "N_ad": [447.6, 478.2, 478.2],
       "NO_ad": [1500.8, 402.6, 402.5, 292.5, 140, 140]}

# Vibrational Frequencies of Gas Phase Molecules (only the vibrational mode, RPBE) 

vibgas = {"O2_g": [1894.0],
	  "N2_g": [2370.1],
	  "NO_g": [1532.7]}
