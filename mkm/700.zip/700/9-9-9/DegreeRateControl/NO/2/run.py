#Version 7-DRC Special
# User input for perturbing free energies of a specific species by a delta. Set delta to zero for volcano
# For DRC analysis MUST set a long simulation time since the output csv file must be ordered. 

import os
import numpy as np
import csv

#user inputs
#Do a quick run with time = 1000 to generate decent guesses
#Do a longer run subsequently with higher value of t to converge unconverged points

BE_initial = -12  #Actual site stability e.g. dimer or trimer
BE_final = -20 #Actual site stability e.g. dimer or trimer
num_intervals = 50
T = 700 #K
Conv = 0.05 #Fraction with respect to NO
metal = "Pt"  #Site composition
CN = "9-9-9"  #Site coordination number
factor = 3 #Division factor
time = 300000 #Integration time for first run
run = 1 #1 if it fresh, > 1 if its a restart, update accordingly 

#DRC Parameters
species = "G_NOs"
delta = 1.25*10**-3

#Dont change anything below 

filename_g = "free_energies.csv"  #Generate free energy file
filename_u = "unconv_rates_{}.csv".format(run)   #Generate file where any converged rates are dumped
filename_c = "rates.csv"          #Generate file where only converged rates are dumped
filename_k = "rateconst.csv"      #Generate rate constant file
filename_g_abs = "abs_free_energies.csv" #Generate file with absolute free energies 

#First four are the thermodynamic free energies, the last three are the kinetic barriers
fields = ["NO(g) + * -> NO*", "NO* + * -> N* + O*", "2N* -> N2(g) + 2*", "2O* -> O2(g) + 2*", "NO_diss", "N2_diss", "O2_diss"]
ratefields = ['BE_site (eV)', 'NO*', 'N*', 'O*', '*', 'rate-step-2 (s-1)', 'rate-step-3 (s-1)']
G_abs_fields = ['G_s', 'G_NOs', 'G_Os', 'G_Ns', 'G_NOts', 'G_N2ts', 'G_O2ts']

with open(filename_g, 'w') as csvfile:
	csvwriter = csv.writer(csvfile)
	csvwriter.writerow(fields)

with open(filename_k, 'w') as csvfile:
	csvwriter = csv.writer(csvfile)
	csvwriter.writerow(fields)

with open(filename_u, 'w') as csvfile:
	csvwriter = csv.writer(csvfile)
	csvwriter.writerow(ratefields)

with open(filename_g_abs, 'w') as csvfile:
	csvwriter = csv.writer(csvfile)
	csvwriter.writerow(G_abs_fields)


#Generate Binding Energies for a Fresh Run 

if run == 1:

	os.system("mkdir DetailedRates")

	with open(filename_c, 'a') as csvfile:   #Note this file, rates.csv will be continuously appended 
		csvwriter = csv.writer(csvfile)
		csvwriter.writerow(ratefields)

	BE = np.linspace((1/factor)*BE_final, (1/factor)*BE_initial, num_intervals)

#Generate Binding Energies for Restarts

if run > 1:
	
	BE = []

	#Read unvonverged binding energies from the previous unconverged file
	with open("unconv_rates_{}.csv".format(run-1), 'r') as csvfile:
		reader = csv.reader(csvfile)
		i = 0
		for row in reader:
			if i > 0:
				BE.append(float(row[0]))
			i = i + 1

#Generate Free Energies 
for i  in range(len(BE)):
	os.system("python free_energies.py {} {:.2f} {} {} {} {}".format(T, BE[i], metal, CN, species, delta))

#Generate Kinetic Data 
for i in range(len(BE)):
	os.system("python kinetics.py {} {} {} {} {}".format(i+1, BE[i], Conv, time, run))

