#Calculates the general degree of rate control from changes in free energies

import numpy as np
import csv
import os, sys
from scipy import stats

#index to read the kinetic barriers
index_k = 1

#Read rates from the DRC analysis 

def readrates(filename):

	with open(filename, "r") as csvfile:
		reader = csv.reader(csvfile)
		X =  [row for i, row in enumerate(reader)]

		#Convert list to numpy array
		X = np.array(X)
		#Delete the top row
		X_new = np.delete(X, 0, 0)
		#Convert the strings to integers
		X_float = X_new.astype(float)
#		X_sort = np.sort(X_float, axis = 0)
		X_sort2 = np.delete(X_float, np.s_[1:6], 1)

	return(X_sort2)

def read_deltaG_abs(filename, index):
	
	G = []

	with open(filename, "r") as csvfile:
		reader = csv.reader(csvfile)

		i = 0 
		
		for row in reader:
			if i > 0:
				G.append(-float(row[index])/((700*8.314)/96488.46))
			i = i + 1

	return(G)


#Rates and free energies at m4
ratesm4 = readrates("../m4/rates.csv")
rates_m4 = np.log(np.delete(ratesm4, 0, 1).flatten())
free_m4 = read_deltaG_abs("../m4/abs_free_energies.csv", index_k)

#Rates and kinetics at m2
ratesm2 = readrates("../m2/rates.csv")
rates_m2 = np.log(np.delete(ratesm2, 0, 1).flatten())
free_m2 = read_deltaG_abs("../m2/abs_free_energies.csv", index_k)

#Rates and kinetics at 0
rates0 = readrates("../0/rates.csv")
rates_0 = np.log(np.delete(rates0, 0, 1).flatten())
free_0 = read_deltaG_abs("../0/abs_free_energies.csv", index_k)

#Rates and kinetics at 2
rates2 = readrates("../2/rates.csv")
rates_2 = np.log(np.delete(rates2, 0, 1).flatten())
free_2 = read_deltaG_abs("../2/abs_free_energies.csv", index_k)

#Rates and kinetics at 4
rates4 = readrates("../4/rates.csv")
rates_4 = np.log(np.delete(rates4, 0, 1).flatten())
free_4 = read_deltaG_abs("../4/abs_free_energies.csv", index_k)

#Binding Energies of M
binding = np.delete(ratesm4, 1, 1).flatten()

allrates = np.transpose(np.stack((rates_m4, rates_m2, rates_0, rates_2, rates_4)))
allfree = np.transpose(np.stack((free_m4, free_m2, free_0, free_2, free_4)))

DRC = []

for i in range(np.shape(allrates)[0]):
		slope, intercept, r_value, p_value, std_err = stats.linregress(allfree[i], allrates[i])
		DRC.append(np.round(slope,3))

print(DRC)
