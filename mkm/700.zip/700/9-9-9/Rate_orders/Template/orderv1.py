#Calculates the general degree of rate control from changes in free energies

import numpy as np
import csv
import os, sys
from scipy import stats

gas = 'NO'

if gas == 'NO':
	index = 0
elif gas == 'N2':
	index = 1
elif gas == 'O2':
	index = 2

#Read rates from the DRC analysis 

def readrates(filename):

	with open(filename, "r") as csvfile:
		reader = csv.reader(csvfile)
		X =  [row for i, row in enumerate(reader)]

		#Convert list to numpy array
		X = np.array(X)
		#Delete the top row
		X_new = np.delete(X, 0, 0)
		#Convert the strings to integers
		X_float = X_new.astype(float)
#		X_sort = np.sort(X_float, axis = 0)
		X_sort2 = np.delete(X_float, np.s_[1:6], 1)

	return(X_sort2)

#Determine the pressures under various conditions

def pressures(Gas, DeltaP):

	P0 = 100000
	Conv = 0.05 

	if Gas == 'NO':
		PNOin = (1000+DeltaP)/P0
		Xp = (1000*Conv)/(1000 + DeltaP)
		PNOout = PNOin*(1-Xp)
		PN2out = PNOin*(Xp/2)
		PO2out = PNOin*(Xp/2)

	elif Gas == 'N2':

		PNOin = (1000)/P0
		PNOout = PNOin*(1-Conv)
		PN2out = ((Conv/2)*PNOin)+(DeltaP/P0)
		PO2out = (Conv/2)*PNOin

	elif Gas == 'O2':

		PNOin = (1000)/P0
		PNOout = PNOin*(1-Conv)
		PN2out = (Conv/2)*PNOin
		PO2out = ((Conv/2)*PNOin)+(DeltaP/P0)

	P = [PNOout, PN2out, PO2out]

	return(P)

#Rates at m10
ratesm10 = readrates("../m10/rates.csv")
rates_m10 = np.log(np.delete(ratesm10, 0, 1).flatten())

#Rates at m5
ratesm5 = readrates("../m5/rates.csv")
rates_m5 = np.log(np.delete(ratesm5, 0, 1).flatten())

#Rates at 0
rates0 = readrates("../0/rates.csv")
rates_0 = np.log(np.delete(rates0, 0, 1).flatten())

#Rates at 5
rates5 = readrates("../5/rates.csv")
rates_5 = np.log(np.delete(rates5, 0, 1).flatten())

#Rates at 10
rates10 = readrates("../10/rates.csv")
rates_10 = np.log(np.delete(rates10, 0, 1).flatten())

#Binding Energies of M
binding = np.delete(ratesm10, 1, 1).flatten()

allrates = np.transpose(np.stack((rates_m10, rates_m5, rates_0, rates_5, rates_10)))
pressure_gas = np.log(np.array([pressures(gas, -10)[index], pressures(gas, -5)[index], pressures(gas, 0)[index], pressures(gas, 5)[index], pressures(gas, 10)[index]]))

#print(rates_m10)
#print(rates_m5)
#print(rates_0)
#print(rates_5)
#print(rates_10)

order = []

for i in range(np.shape(allrates)[0]):
		slope, intercept, r_value, p_value, std_err = stats.linregress(pressure_gas, allrates[i])
		order.append(np.round(slope,3))

		if r_value**2 < 0.95:
			print(r_value**2)
			print("Treebeard: Don't be hasty!")

print(order)
