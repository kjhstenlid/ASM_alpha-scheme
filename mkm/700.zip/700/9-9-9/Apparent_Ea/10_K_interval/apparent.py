import numpy as np
import csv
import os, sys 
from scipy import stats

Tinv = [1/680, 1/690, 1/700, 1/710, 1/720]
eVJ = 96488.46
filename_app = 'eapp.csv'

def readrates(filename, index):

	with open(filename, 'r') as file:
		reader = csv.reader(file)

		i = 0 #Count
		rates = []

		for row in reader:
			if i > 0:
				if index > 0:
					rates.append(np.log(float(row[index])))
				elif index == 0:
					rates.append(round(float(row[index]), 2))
			i = i+1
	return rates

rates696 = readrates(filename = 'rates680.csv', index = 5)
rates698 = readrates(filename = 'rates690.csv', index = 5)
rates700 = readrates(filename = 'rates700.csv', index = 5)
rates702 = readrates(filename = 'rates710.csv', index = 5)
rates704 = readrates(filename = 'rates720.csv', index = 5)
BE_M = readrates(filename = 'rates680.csv', index = 0)

allrates = np.transpose(np.stack((rates696, rates698, rates700, rates702, rates704)))

Eapp = []

for i in range(np.shape(allrates)[0]):
	slope, intercept, r_value, p_value, std_err = stats.linregress(Tinv, allrates[i])
	Eapp.append(round((-8.314*slope)/eVJ, 2))

	if r_value**2 < 0.95:
		print(r_value**2)
		print("Treebeard: Don't be hasty!")

#output= np.stack((BE_M, Eapp), axis = 1)

for i in range(len(BE_M)):
	
	rows_eapp = [ [BE_M[i], Eapp[i]]]
	
	with open(filename_app, 'a') as csvfile:
		csvwriter = csv.writer(csvfile)
		csvwriter.writerows(rows_eapp)



