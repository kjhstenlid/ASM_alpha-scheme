import pandas as pd
import csv
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import numpy as np

# conversion factor kJ to eV
# 1 eV = 96.48846 kJ/mol
kJeV = 96.48846
factor = 3
BE_final = -20
BE_initial = -12
num_intervals = 50


# read the rates at the five different temperatures into a pandas dataframe
df=pd.concat(map(pd.read_csv, ["rates696.csv", "rates698.csv", "rates700.csv", "rates702.csv", "rates704.csv"]))

#header of csv file and filname of .csv file
header = [['BE_site (eV)','Ea (eV)']]

filename = 'Ea_9-9-9.csv'

BE = np.round(np.linspace((1/factor)*BE_final, (1/factor)*BE_initial, num_intervals), decimals = 2)
Ea = []

#write header into .csv file
with open(filename, 'w+') as csvfile:

	csvwriter = csv.writer(csvfile)
	csvwriter.writerows(header)

for i in BE:
	data=df.loc[(df['BE_site (eV)']==i)]
#	print(data.iloc[:,1].values)
	x = 1000/data.iloc[:,0].values.reshape(-1, 1)
	y = np.log(data.iloc[:,-2].values)
	lr = LinearRegression()
	lr.fit(x,y)
	y_pred = lr.predict(x)
	Eai = float(-(lr.coef_*8.314)/kJeV)
	Ea.append(Eai)
	rows = [[i,Eai]]

	with open(filename, 'a') as csvfile:
		csvwriter = csv.writer(csvfile)
		csvwriter.writerows(rows)
	
