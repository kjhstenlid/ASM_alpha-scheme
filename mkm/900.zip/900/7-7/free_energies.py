#Site Specific Microkinetic Model Version 7
#For a given site stability, determines the Free energies of all species at a given T, 1 bar
#Includes ZPE corrections for NO*, O*, N*, N2(g), O2(g), NO(g) determined using DFT calculations on Pt
#Added mechanism for a DRC calculation by setting a delta for a given species. Delta and species
# included from the run.py file. Select delta as zero for constructing main volcano
#Generates a new script for absolute free energies of surface species, transition states 

from __future__ import division
from constants import *
from decimal import *
import numpy as np
import math
import os, sys
import csv

#CSV files where the free energies and kinetic constants are stored
filename_g = 'free_energies.csv'
filename_k = 'rateconst.csv'
filename_g_abs = 'abs_free_energies.csv'

#Inputs read from the run.py #script 
T = float(sys.argv[1]) #eV
Site = float(sys.argv[2]) #eV
metal = sys.argv[3]
CN = sys.argv[4]
species = sys.argv[5]
delta = float(sys.argv[6])

mT = T/1000 #Needed for shomate equation
P0 = 100000 #Pa
R = 8.314 #kJ/mol
h = 6.626*10**-34 # J s
c = 299792458 #m/s
Na = 6.023*10**23 #atoms per mole
M_NO = 4.98185E-26 #Mass of NO in kg pe atom
A_site = 1*10**-19 #m2
eVJ = 96488.46 # 1 eV to J/mol K
eV = 1.6*10**-19 #eV to J
RyeV = 13.605662285137 # 1 Ry to eV
kb = R/Na #Boltzmanns constant
kbT = kb*T
pi = math.pi
pre = kb*T/h #Pre-exp factor for surface reactions

#Gas Phase Energies (ZPE corrected)

E_N2g = gas_energies_dft["N2"]*RyeV + 0.5*((vibgas["N2_g"][0]*100*h*c)/eV)
E_O2g = gas_energies_dft["O2"]*RyeV + 0.5*((vibgas["O2_g"][0]*100*h*c)/eV) 
E_NOg = gas_energies_dft["NO"]*RyeV + 0.5*((vibgas["NO_g"][0]*100*h*c)/eV)

#Adsorbate Binding Energies from site specific scaling relations (ZPE corrected)

BE_NOs = np.dot(site_specific_NO[metal][CN], [Site, 1]) + 0.5*((sum(vib["NO_ad"])*100*h*c)/eV) - 0.5*((vibgas["NO_g"][0]*100*h*c)/eV)  
BE_Ns = np.dot(site_specific_N[metal][CN], [Site, 1]) + 0.5*((sum(vib["N_ad"])*100*h*c)/eV) - 0.5*0.5*((vibgas["N2_g"][0]*100*h*c)/eV)
BE_Os = np.dot(site_specific_O[metal][CN], [Site, 1]) + 0.5*((sum(vib["N_ad"])*100*h*c)/eV) -0.5*0.5*((vibgas["O2_g"][0]*100*h*c)/eV)

#ETS (ETS = Energy of TS - Energy of clean surface - Energy of un-dissociated molecule
Ediss_NO = BE_Ns + BE_Os + (0.5*E_N2g + 0.5*E_O2g - E_NOg)
Ediss_O2 = 2*BE_Os
Ediss_N2 = 2*BE_Ns
 
BE_NOts = np.dot(TSS_NO[CN], [Ediss_NO, 1])
BE_O2ts = np.dot(TSS_O2[CN], [Ediss_O2, 1]) 
BE_N2ts = np.dot(TSS_N2[CN], [Ediss_N2, 1])

#Entropy of gas phase species
temp_mat = [np.log(mT), mT, (mT**2)/2, (mT**3)/3, -1/(2*(mT**2)), 1]

S_NOg = np.dot(Shomate["NO"],temp_mat) / eVJ
S_N2g = np.dot(Shomate["N2"],temp_mat) / eVJ
S_O2g = np.dot(Shomate["O2"],temp_mat) / eVJ

#Entropy of surface species
def S_vib(vib):
	S=0
	for i in range(len(vib)):
		hvc = h*c*vib[i]*100
		S = S + ( (hvc/kbT)/(np.exp(hvc/kbT)-1) - np.log(1-np.exp(-hvc/kbT)) )
	return S*R

S_Ns = S_vib(vib["N_ad"]) / eVJ
S_Os = S_vib(vib["O_ad"]) / eVJ
S_NOs = S_vib(vib["NO_ad"]) / eVJ

S_N2ts = 2*S_Ns # S for TS same as IS
S_O2ts = 2*S_Os # S for TS same as IS
S_NOts = S_NOs #S for TS same as IS

#Free energies of species referenced to (G* + GNO(g))

G_s = -(E_NOg - T*S_NOg)   #Empty Site
G_NOs = BE_NOs - T*(S_NOs-S_NOg)
G_Os = BE_Os - T*(S_Os - 0.5*S_O2g) - (E_NOg - 0.5*E_O2g) + T*(S_NOg - 0.5*S_O2g)
G_Ns = BE_Ns - T*(S_Ns - 0.5*S_N2g) - (E_NOg - 0.5*E_N2g) + T*(S_NOg - 0.5*S_N2g) 
G_NOts = BE_NOts - T*(S_NOts - S_NOg)
G_N2ts = BE_N2ts - T*(S_N2ts - S_N2g) - (E_NOg - E_N2g) + T*(S_NOg - S_N2g)
G_O2ts = BE_O2ts - T*(S_O2ts - S_O2g) - (E_NOg - E_O2g) + T*(S_NOg - S_O2g)
G_NOg = E_NOg - T*S_NOg
G_N2g = E_N2g - T*S_N2g
G_O2g = E_O2g - T*S_O2g

#Adjust free energies for degree of rate control analysis 

deltaGstr = ['G_s', 'G_NOs', 'G_Os', 'G_Ns', 'G_NOts', 'G_N2ts', 'G_O2ts', 'G_NOg', 'G_N2g', 'G_O2g']
deltaG = [G_s, G_NOs, G_Os, G_Ns, G_NOts, G_N2ts, G_O2ts, G_NOg, G_N2g, G_O2g]

if species in deltaGstr:
	i = deltaGstr.index(species)
	deltaG[i] = deltaG[i] + delta

#Free energies of reactions
# Reaction 1: NO(g) + * -> NO* 
# Reaction 2: NO* + * -> N* + O* 
# Reaction 3: N* + N* -> N2(g) + 2*
# Reaction 4: O* + O* -> O2(g) + 2*

#dG1 = G_NOs - G_s - G_NOg
dG1 = deltaG[1] - deltaG[0] - deltaG[7]
#dG2 = G_Ns + G_Os - G_NOs - G_s
dG2 = deltaG[3] + deltaG[2] - deltaG[1] - deltaG[0]
#dG3 = G_N2g + 2*G_s -2*G_Ns
dG3 = deltaG[8] + 2*deltaG[0] - 2*deltaG[3]
#dG4 = G_O2g + 2*G_s -2*G_Os
dG4 = deltaG[9] + 2*deltaG[0] - 2*deltaG[2]
#dG2_act = G_NOts - G_NOs
dG2_act = deltaG[4] - deltaG[1]
#dG3_act = G_N2ts + G_s - 2*G_Ns
dG3_act = deltaG[5] + deltaG[0] - 2*deltaG[3]
#dG4_act = G_O2ts + G_s - 2*G_Os
dG4_act = deltaG[6] + deltaG[0] - 2*deltaG[2]

dG_all = [dG1, dG2, dG3, dG4]
dG_act_all = [0, dG2_act, dG3_act, dG4_act]
Keq_all = []
kf = []
kb = []

#Equilibrium constants of steps

for i in range(len(dG_all)):
	Keq_all.append(math.exp(-(dG_all[i]*eVJ)/(R*T)))
	kf.append(pre*math.exp(-(dG_act_all[i]*eVJ)/(R*T)))
	kb.append(kf[i]/Keq_all[i])

#Update equilibrium constant of the first step based on collision theory, pre-exp factor is 1.
kf[0] = A_site/((2*pi*M_NO*kbT)**0.5)
kb[0] = (kf[0]/Keq_all[0])*P0

rows_G = [ [dG1, dG2, dG3, dG4, dG2_act, dG3_act, dG4_act]]
rows_k = [ [kf[0], kb[0], kf[1], kb[1], kf[2], kb[2], kf[3], kb[3]]]
rows_G_abs = [ [deltaG[0], deltaG[1], deltaG[2], deltaG[3], deltaG[4], deltaG[5], deltaG[6]]]

with open(filename_g, 'a') as csvfile:

	csvwriter = csv.writer(csvfile)
	csvwriter.writerows(rows_G)

with open(filename_k, 'a') as csvfile:

	csvwriter = csv.writer(csvfile)
	csvwriter.writerows(rows_k)

with open(filename_g_abs, 'a') as csvfile:

	csvwriter = csv.writer(csvfile)
	csvwriter.writerows(rows_G_abs)
