#Version7
#Segregate the unconverged and converged points
#Only restart the unconverged points
#Added function for rate order. Uses two inputs, DeltaP, and which gas
#See if conditions to understand how pressure of one gas is varied keeping the others constant

import csv
import sys, os
import numpy as np
import math
from decimal import *
from scipy.integrate import solve_ivp
from scipy.integrate import odeint
from scipy.optimize import brentq

point = int(sys.argv[1])  #Line in CSV file being calculated
BE_M = float(sys.argv[2]) #Site stability (normalized)
DeltaP = float(sys.argv[3]) #Change in the pressure of a species
Gas = sys.argv[4] #Gas whose pressure is being determined 
tfinal = int(sys.argv[5]) #Integration time
run = int(sys.argv[6]) #Run number

P0 = 100000 #Pa reference pressure
Conv = 0.05 #Conversion with respect to NO in the base case

#For first run initialize coverage randomly. For first volcano, use coverages for preceeding data point
# as an initial guess. 

if run == 1:
	X0 = [0.988010567, 0.000117974, 4.57E-05]
	
#For subsequent runs with higher integration times, read X0 from the previous iteration
#The previous .csv file should be in the directory as ratesold.csv
#The integration time is set using sys.argv[5] from the main run.py file

elif run > 1:

	with open('unconv_rates_{}.csv'.format(run-1), 'r') as file:
		reader = csv.reader(file)
		X =  [row for i, row in enumerate(reader) if i == point][0]
		X0 = [float(X[1]), float(X[2]), float(X[3])]

filename = 'rateconst.csv'

with open(filename, 'r') as file:
	reader = csv.reader(file)
	k = [row for i, row in enumerate(reader) if i == point][0]

k = np.array(k)
k = k.astype(float)

#Mass Balance in the base case

if Gas == 'NO':

	PNOin = (1000+DeltaP)/P0 
	Xp = (1000*Conv)/(1000 + DeltaP)
	PNOout = PNOin*(1-Xp)
	PN2out = PNOin*(Xp/2)
	PO2out = PNOin*(Xp/2)

elif Gas == 'N2':

	PNOin = (1000)/P0
	PNOout = PNOin*(1-Conv)
	PN2out = ((Conv/2)*PNOin)+(DeltaP/P0)
	PO2out = (Conv/2)*PNOin

elif Gas == 'O2':

	PNOin = (1000)/P0
	PNOout = PNOin*(1-Conv)
	PN2out = (Conv/2)*PNOin
	PO2out = ((Conv/2)*PNOin)+(DeltaP/P0)

#PNOin = 1000/P0 #Partial pressure of NO in
#PNOout = PNOin*(1-Conv) #Partial pressure of NO out
#PN2out = (Conv/2)*PNOin #Partial pressure of N2 out
#PO2out = (Conv/2)*PNOin #Partial pressure of O2 out

#Pressures to be considered
P = [PNOout, PN2out, PO2out]

def dX_dt(t, X):

	return [k[0]*P[0]*P0*(1-X[0]-X[1]-X[2]) - k[1]*X[0] - k[2]*X[0]*(1-X[0]-X[1]-X[2]) + k[3]*X[1]*X[2],
		k[2]*X[0]*(1-X[0]-X[1]-X[2]) - k[3]*X[1]*X[2] - 2*k[4]*X[1]*X[1] + 2*k[5]*P[1]*(1-X[0]-X[1]-X[2])*(1-X[0]-X[1]-X[2]),
		k[2]*X[0]*(1-X[0]-X[1]-X[2]) - k[3]*X[1]*X[2] - 2*k[6]*X[2]*X[2] + 2*k[7]*P[2]*(1-X[0]-X[1]-X[2])*(1-X[0]-X[1]-X[2])]

def jac(t, X):

	J00 = -k[0]*P[0]*P0 - k[1] -k[2]*(1-X[0]-X[1]-X[2]) + k[2]*X[0]
	J01 = -k[0]*P[0]*P0 + k[2]*X[0] + k[3]*X[2]
	J02 = -k[0]*P[0]*P0 + k[2]*X[0] + k[3]*X[1]

	J10 = -k[2]*X[0] + k[2]*(1-X[0]-X[1]-X[2]) - 4*k[5]*P[1]*(1-X[0]-X[1]-X[2])
	J11 = -k[2]*X[0] - k[3]*X[2] - 4*k[4]*X[1] - 4*k[5]*P[1]*(1-X[0]-X[1]-X[2])
	J12 = -k[2]*X[0] - k[3]*X[1] - 4*k[5]*P[1]*(1-X[0]-X[1]-X[2])

	J20 = k[2]*(1-X[0]-X[1]-X[2]) -k[2]*X[0] - 4*k[7]*P[2]*(1-X[0]-X[1]-X[2])
	J21 = -k[2]*X[0] -k[3]*X[2] - 4*k[7]*P[2]*(1-X[0]-X[1]-X[2])
	J22 = -k[2]*X[0] -k[3]*X[1] - 4*k[7]*P[2]*(1-X[0]-X[1]-X[2])

	return([[J00, J01, J02], [J10, J11, J12], [J20, J21, J22]])

Xs = solve_ivp(dX_dt, [0, tfinal], X0, method='Radau', atol = 1e-25, rtol = 1e-10, jac=jac)

time = Xs.t
Sol = Xs.y

Xc = np.zeros(3)
Xc[0] = Decimal(Sol[0][-1])
Xc[1] = Decimal(Sol[1][-1])
Xc[2] = Decimal(Sol[2][-1])
theta = 1-Xc[0]-Xc[1]-Xc[2]
rate2 = k[2]*Xc[0]*(1-Xc[0]-Xc[1]-Xc[2]) - k[3]*Xc[1]*Xc[2]
rate3 = k[4]*Xc[1]*Xc[1] - k[5]*P[1]*(1-Xc[0]-Xc[1]-Xc[2])*(1-Xc[0]-Xc[1]-Xc[2])
rate4 = k[6]*Xc[2]*Xc[2] - k[7]*P[2]*(1-Xc[0]-Xc[1]-Xc[2])*(1-Xc[0]-Xc[1]-Xc[2]) 

ratio1 = rate3/rate4
ratio2 = rate2/rate3

print("Convergence criteria 1 (should be 1): {}".format(ratio1))
print("Convergence criteria 2 (should be 2): {}".format(ratio2))

datfile = open('rates_{:.2f}.dat'.format(-BE_M), 'w')
datfile.write('ODE solution\n\n')
datfile.write('Coverages\n\n')
datfile.write('Coverage of NO*: {}\n'.format(Xc[0]))
datfile.write('Coverage of N*: {}\n'.format(Xc[1]))
datfile.write('Coverage of O*: {}\n'.format(Xc[2]))
datfile.write(('Coverage of *: {}\n\n'.format(1-Xc[0]-Xc[1]-Xc[2])))
datfile.write('Rates\n\n')
datfile.write('Net rate, Step 1: {}\n'.format(k[0]*P[0]*P0*(1-Xc[0]-Xc[1]-Xc[2]) - k[1]*Xc[0]))
print('Net rate, Step 2: {}'.format(k[2]*Xc[0]*(1-Xc[0]-Xc[1]-Xc[2]) - k[3]*Xc[1]*Xc[2]))
datfile.write('Net rate, Step 2: {}\n'.format(k[2]*Xc[0]*(1-Xc[0]-Xc[1]-Xc[2]) - k[3]*Xc[1]*Xc[2]))
print('Net rate, Step 3: {}'.format(k[4]*Xc[1]*Xc[1]-k[5]*P[1]*(1-Xc[0]-Xc[1]-Xc[2])*(1-Xc[0]-Xc[1]-Xc[2])))
datfile.write('Net rate, Step 3: {}\n'.format(k[4]*Xc[1]*Xc[1] - k[5]*P[1]*(1-Xc[0]-Xc[1]-Xc[2])*(1-Xc[0]-Xc[1]-Xc[2])))
datfile.write('Net rate, Step 4: {}\n'.format(k[6]*Xc[2]*Xc[2] - k[7]*P[2]*(1-Xc[0]-Xc[1]-Xc[2])*(1-Xc[0]-Xc[1]-Xc[2])))

datfile.write("Convergence criteria 1 (should be 1): {}\n".format(ratio1))
datfile.write("Convergence criteria 2 (should be 2): {}\n".format(ratio2))

datfile.write('Forward rate, Step 1: {}\n'.format(k[0]*P[0]*P0*(1-Xc[0]-Xc[1]-Xc[2])))
datfile.write('Reverse rate, Step 1: {}\n'.format(k[1]*Xc[0]))
datfile.write('Forward rate, Step 2: {}\n'.format(k[2]*Xc[0]*(1-Xc[0]-Xc[1]-Xc[2])))
datfile.write('Reverse rate, Step 2: {}\n'.format(k[3]*Xc[1]*Xc[2]))
datfile.write('Forward rate, Step 3: {}\n'.format(k[4]*Xc[1]*Xc[1]))
datfile.write('Reverse rate, Step 3: {}\n'.format(k[5]*P[1]*(1-Xc[0]-Xc[1]-Xc[2])*(1-Xc[0]-Xc[1]-Xc[2])))
datfile.write('Forward rate, Step 4: {}\n'.format(k[6]*Xc[2]*Xc[2]))
datfile.write('Reverse rate, Step 4: {}\n\n'.format(k[7]*P[2]*(1-Xc[0]-Xc[1]-Xc[2])*(1-Xc[0]-Xc[1]-Xc[2])))

datfile.close()

os.system("mv rates_{:.2f}.dat DetailedRates".format(-BE_M))

rows = [ [BE_M, Xc[0], Xc[1], Xc[2], theta, rate2, rate3]]

filename_cw = 'rates.csv'   #converged points
filename_uw = 'unconv_rates_{}.csv'.format(run)   #unconverged points 

#If converged write to converged file

if  0.97 < ratio1 < 1.03 and 1.97 < ratio2 < 2.03:

#	print('Valar Dohaeris')

	with open(filename_cw, 'a') as csvfile:

        	csvwriter = csv.writer(csvfile)
        	csvwriter.writerows(rows)

#if unconverged write to unconverged file

else:

#	print('Valar Morghulis')

	with open(filename_uw, 'a') as csvfile:
	
		csvwriter = csv.writer(csvfile)
		csvwriter.writerows(rows)
